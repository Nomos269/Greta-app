/* GRETA · adaptador Supabase
   Hace que la app (la misma que funciona dentro de Claude) guarde sus datos,
   fotos y videos en Supabase y use el entrenador con IA a través de una
   Edge Function. La app no cambia: este archivo implementa las mismas
   funciones que ofrecía Claude (db, assets, sample). */
(function(){
  const CFG = window.GRETA_CONFIG || {};
  const PIXEL = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
  const TABLES = {sesiones:'sesiones', registros:'registros', album:'album'};
  let sb = null, user = null, resolveReady;
  const ready = new Promise(r=>{ resolveReady = r; });

  /* ---------- pantalla de inicio de sesión ---------- */
  const css = `
  .gl-wrap{position:fixed;inset:0;z-index:100;background:var(--bg,#F2F2F7);display:flex;align-items:center;justify-content:center;padding:24px max(20px,env(safe-area-inset-left)) 24px max(20px,env(safe-area-inset-right))}
  .gl-card{width:100%;max-width:380px;display:flex;flex-direction:column;gap:14px}
  .gl-logo{font:800 1.1rem/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;letter-spacing:.2em;color:var(--ink,#1C1C1E)}
  .gl-logo i{font-style:normal;color:var(--tint,#0A66D8)}
  .gl-card h1{margin:0;font:800 2rem/1.1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;letter-spacing:-.02em;color:var(--ink,#1C1C1E)}
  .gl-card p{margin:0;color:var(--muted,#6E6E73);font-size:.95rem}
  .gl-card input{font:inherit;font-size:16px;background:var(--surface,#fff);color:var(--ink,#1C1C1E);border:1px solid var(--line,#E3E3E8);border-radius:12px;padding:12px 14px;min-height:48px;width:100%;box-sizing:border-box}
  .gl-card button{font:600 1rem/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;border:0;border-radius:12px;min-height:48px;cursor:pointer}
  .gl-main{background:var(--tint,#0A66D8);color:#fff}
  .gl-alt{background:none;color:var(--tint,#0A66D8)}
  .gl-msg{min-height:1.2em;font-size:.9rem;color:var(--bad,#D92D20)}
  .gl-msg.ok{color:var(--ok,#1E8E3E)}`;
  function showLogin(note){
    if(document.querySelector('.gl-wrap')) return;
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    const w = document.createElement('div'); w.className = 'gl-wrap';
    w.innerHTML = `<form class="gl-card" novalidate>
      <span class="gl-logo">GRETA<i>·</i>K9</span>
      <h1>Entrar</h1>
      <p>Tu cuenta guarda los datos, fotos y videos de Greta y los sincroniza entre tus teléfonos.</p>
      <label><span class="gl-sr" style="position:absolute;left:-9999px">Correo</span><input type="email" id="gl-email" autocomplete="email" placeholder="Correo" required></label>
      <label><span class="gl-sr" style="position:absolute;left:-9999px">Contraseña</span><input type="password" id="gl-pass" autocomplete="current-password" placeholder="Contraseña (mínimo 6 caracteres)" required minlength="6"></label>
      <div class="gl-msg" id="gl-msg" role="status">${note||''}</div>
      <button class="gl-main" type="submit" id="gl-go">Entrar</button>
      <button class="gl-alt" type="button" id="gl-mode">¿Primera vez? Crear cuenta</button>
    </form>`;
    document.body.appendChild(w);
    let signup = false;
    const msg = (t, ok)=>{ const m = w.querySelector('#gl-msg'); m.textContent = t; m.classList.toggle('ok', !!ok); };
    w.querySelector('#gl-mode').onclick = ()=>{
      signup = !signup;
      w.querySelector('h1').textContent = signup ? 'Crear cuenta' : 'Entrar';
      w.querySelector('#gl-go').textContent = signup ? 'Crear cuenta' : 'Entrar';
      w.querySelector('#gl-mode').textContent = signup ? 'Ya tengo cuenta' : '¿Primera vez? Crear cuenta';
      w.querySelector('#gl-pass').autocomplete = signup ? 'new-password' : 'current-password';
      msg('');
    };
    w.querySelector('form').onsubmit = async e=>{
      e.preventDefault();
      if(!sb){ msg('Falta configurar Supabase. Revisa la guía de instalación.'); return; }
      const email = w.querySelector('#gl-email').value.trim(), password = w.querySelector('#gl-pass').value;
      if(!email || password.length<6){ msg('Escribe tu correo y una contraseña de al menos 6 caracteres.'); return; }
      const btn = w.querySelector('#gl-go'); btn.disabled = true;
      try{
        if(signup){
          const {data, error} = await sb.auth.signUp({email, password});
          if(error) throw error;
          if(!data.session){ msg('Cuenta creada. Revisa tu correo para confirmarla y luego entra aquí.', true); signup = true; w.querySelector('#gl-mode').click(); return; }
          start(data.session.user);
        } else {
          const {data, error} = await sb.auth.signInWithPassword({email, password});
          if(error) throw error;
          start(data.session.user);
        }
      }catch(err){
        const t = String(err && err.message || '');
        msg(/invalid login/i.test(t) ? 'Correo o contraseña incorrectos.' : /confirm/i.test(t) ? 'Confirma tu correo con el enlace que te enviamos y vuelve a intentar.' : /already/i.test(t) ? 'Ese correo ya tiene cuenta. Toca “Ya tengo cuenta”.' : 'No se pudo entrar. Revisa tu conexión e intenta de nuevo.');
      }finally{ btn.disabled = false; }
    };
  }
  function start(u){
    user = u;
    const w = document.querySelector('.gl-wrap'); if(w) w.remove();
    resolveReady();
    startPolling();
    flush();
  }
  window.gretaLogout = async ()=>{ try{ await sb.auth.signOut(); }catch(e){} try{ localStorage.removeItem('greta-urls'); }catch(e){} location.reload(); };

  /* ---------- base de datos ---------- */
  const listeners = {estado:[], sesiones:[], registros:[], album:[]};
  const err = (e)=>({code: /quota|exceed/i.test(e&&e.message||'') ? 'quota_exceeded' : 'unavailable', message: (e&&e.message)||'Error de conexión'});
  /* ---------- modo sin conexión: copia local y cola de cambios ---------- */
  const LS = {
    get(k, d){ try{ const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; }catch(e){ return d; } },
    set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
  };
  const ckey = k=>`greta-cache-${user.id}-${k}`;
  const okey = ()=>`greta-outbox-${user.id}`;
  const isNet = e=>!navigator.onLine || /fetch|network|load failed|timeout|offline/i.test(String((e && (e.message||e)) || ''));
  const outbox = ()=>LS.get(okey(), []);
  function enqueue(op){
    let q = outbox();
    if(op.t==='estado') q = q.filter(o=>o.t!=='estado');
    else q = q.filter(o=>!(o.table===op.table && o.id===op.id));
    q.push(op); LS.set(okey(), q);
  }
  let flushing = false;
  async function flush(){
    if(flushing || !user || !navigator.onLine) return; flushing = true;
    try{
      for(let guard=0; guard<500; guard++){
        const q = outbox(); if(!q.length) break;
        const op = q[0]; let res;
        if(op.t==='estado') res = await sb.from('estado').upsert({user_id:user.id, data:op.data, updated_at:new Date().toISOString()});
        else if(op.t==='upsert') res = await sb.from(op.table).upsert({user_id:user.id, id:op.id, ts:op.ts, data:op.data}, {onConflict:'user_id,id'});
        else res = await sb.from(op.table).delete().eq('user_id', user.id).eq('id', op.id);
        if(res.error){ if(isNet(res.error)) break; console.warn('GRETA: cambio descartado', res.error); }
        const now = outbox();
        if(now.length && JSON.stringify(now[0])===JSON.stringify(op)) now.shift();
        LS.set(okey(), now);
      }
    } finally { flushing = false; }
    refresh();
  }
  window.addEventListener('online', ()=>flush());

  async function fetchEstado(){
    const pend = outbox().find(o=>o.t==='estado');
    if(pend) return pend.data;
    try{
      const {data, error} = await sb.from('estado').select('data').eq('user_id', user.id).maybeSingle();
      if(error) throw error;
      if(!data && window.GRETA_SEED){
        const seed = window.GRETA_SEED;
        await sb.from('estado').upsert({user_id:user.id, data:seed, updated_at:new Date().toISOString()});
        LS.set(ckey('estado'), seed);
        return seed;
      }
      const d = data ? data.data : null;
      LS.set(ckey('estado'), d);
      return d;
    }catch(e){
      const c = LS.get(ckey('estado'), undefined);
      if(c !== undefined) return c;
      throw e;
    }
  }
  async function fetchCol(name){
    let rows;
    try{
      const {data, error} = await sb.from(TABLES[name]).select('id,data').eq('user_id', user.id).order('ts',{ascending:false}).limit(1000);
      if(error) throw error;
      rows = data || [];
      LS.set(ckey(name), rows);
    }catch(e){
      rows = LS.get(ckey(name), null);
      if(!rows) throw e;
    }
    // aplicar cambios pendientes de sincronizar
    const ops = outbox().filter(o=>o.table===TABLES[name]);
    if(ops.length){
      const m = new Map(rows.map(r=>[r.id, r]));
      ops.forEach(o=>{ if(o.t==='upsert') m.set(o.id, {id:o.id, data:o.data}); else m.delete(o.id); });
      rows = [...m.values()].sort((a,b)=>(b.data.ts||0)-(a.data.ts||0));
    }
    return rows;
  }
  const docSnap = d=>({exists: !!d, data: ()=> d ? JSON.parse(JSON.stringify(d)) : undefined, metadata:{fromCache:false, hasPendingWrites:false}});
  const colSnap = rows=>({docs: rows.map(r=>({id:r.id, exists:true, data:()=>JSON.parse(JSON.stringify(r.data))})), size:rows.length, empty:!rows.length, metadata:{fromCache:false, hasPendingWrites:false}});
  let chain = Promise.resolve();
  function refresh(which){
    chain = chain.then(()=>doRefresh(which)).catch(()=>{});
    return chain;
  }
  async function doRefresh(which){
    if(!user) return;
    const keys = which ? [which] : Object.keys(listeners).filter(k=>listeners[k].length);
    for(const k of keys){
      if(!listeners[k].length) continue;
      try{
        if(k==='estado'){ const d = await fetchEstado(); listeners.estado.forEach(l=>l.next(docSnap(d))); }
        else { const rows = await fetchCol(k); listeners[k].forEach(l=>l.next(colSnap(rows))); }
      }catch(e){
        console.warn('GRETA sync', k, e);
      }
    }
  }
  let pollTimer = null;
  function startPolling(){
    if(pollTimer) return;
    pollTimer = setInterval(()=>{ if(document.visibilityState==='visible') refresh(); }, 60000);
    document.addEventListener('visibilitychange', ()=>{ if(document.visibilityState==='visible') refresh(); });
  }
  function listen(key, next, error){
    const l = {next, error}; listeners[key].push(l);
    refresh(key);
    return ()=>{ listeners[key] = listeners[key].filter(x=>x!==l); };
  }
  const DB = Object.freeze({
    doc(path){
      if(path!=='greta/estado') throw new TypeError('Ruta no soportada: '+path);
      return {
        async get(){ return docSnap(await fetchEstado()); },
        async set(data){
          LS.set(ckey('estado'), data);
          if(!navigator.onLine){ enqueue({t:'estado', data}); return; }
          const {error} = await sb.from('estado').upsert({user_id:user.id, data, updated_at:new Date().toISOString()});
          if(error){ if(isNet(error)){ enqueue({t:'estado', data}); return; } throw err(error); }
          if(outbox().length) flush();
        },
        onSnapshot(next, error){ return listen('estado', next, error); }
      };
    },
    collection(name){
      if(!TABLES[name]) throw new TypeError('Colección no soportada: '+name);
      const q = {
        orderBy(){ return q; }, limit(){ return q; }, where(){ return q; },
        async get(){ return colSnap(await fetchCol(name)); },
        onSnapshot(next, error){ return listen(name, next, error); },
        doc(id){
          return {
            async set(data){
              const op = {t:'upsert', table:TABLES[name], id, ts:data.ts||Date.now(), data};
              if(!navigator.onLine){ enqueue(op); return; }
              const {error} = await sb.from(TABLES[name]).upsert({user_id:user.id, id, ts:op.ts, data}, {onConflict:'user_id,id'});
              if(error){ if(isNet(error)){ enqueue(op); return; } throw err(error); }
            },
            async delete(){
              const op = {t:'delete', table:TABLES[name], id};
              if(!navigator.onLine){ enqueue(op); return; }
              const {error} = await sb.from(TABLES[name]).delete().eq('user_id', user.id).eq('id', id);
              if(error){ if(isNet(error)){ enqueue(op); return; } throw err(error); }
            }
          };
        }
      };
      return q;
    }
  });

  /* ---------- fotos y videos ---------- */
  const MAX = 50*1024*1024;
  const EXT = {'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov'};
  const ASSETS = Object.freeze({
    async upload(blob, opts){
      const type = (opts && opts.type) || blob.type || 'application/octet-stream';
      if(blob.size > MAX) throw {code:'too_large'};
      if(!EXT[type]) throw {code:'unsupported_type'};
      const id = `${user.id}/${(crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+Math.random().toString(36).slice(2))}.${EXT[type]}`;
      const {error} = await sb.storage.from('media').upload(id, blob, {contentType:type, upsert:false, cacheControl:'31536000'});
      if(error) throw {code: /exceed|too large|maximum/i.test(error.message||'') ? 'too_large' : 'upstream_error', message:error.message};
      urlCache[id] = null; // se firmará al mostrarse
      return {id, url:'', sizeBytes:blob.size, contentType:type};
    },
    async delete(id){ const {error} = await sb.storage.from('media').remove([id]); if(error) throw {code:'upstream_error'}; delete urlCache[id]; saveUrls(); return {deleted:true}; },
    async list(){ return {assets:[], usage:{}}; }
  });
  let urlCache = {};
  try{ urlCache = JSON.parse(localStorage.getItem('greta-urls')||'{}'); }catch(e){}
  const saveUrls = ()=>{ try{ localStorage.setItem('greta-urls', JSON.stringify(urlCache)); }catch(e){} };
  const queue = new Set(); let flushT = null;
  window.gretaMediaUrl = id=>{
    const c = urlCache[id];
    if(c && c.url && c.exp > Date.now()+3600e3) return c.url;
    if(sb && user){ queue.add(id); clearTimeout(flushT); flushT = setTimeout(flushUrls, 40); }
    return PIXEL;
  };
  async function flushUrls(){
    const ids = [...queue]; queue.clear(); if(!ids.length) return;
    const {data, error} = await sb.storage.from('media').createSignedUrls(ids, 7*24*3600);
    if(error || !data) return;
    const exp = Date.now() + 7*24*3600e3 - 60e3;
    data.forEach(d=>{ if(d.signedUrl) urlCache[d.path] = {url:d.signedUrl, exp}; });
    saveUrls();
    if(typeof render==='function') render();
    if(typeof renderSheet==='function' && typeof sheetKind!=='undefined' && sheetKind==='media') renderSheet();
  }

  /* ---------- entrenador con IA ---------- */
  async function SAMPLE(prompt, opts){
    const {data, error} = await sb.functions.invoke('coach', {body:{prompt}});
    if(error || !data || data.error){ throw {code:'unavailable', message:(data&&data.error)||'Sin respuesta'}; }
    const text = String(data.text||'');
    if(opts && typeof opts.onText==='function') opts.onText({text, delta:text});
    return {text, truncated:false};
  }

  /* ---------- interfaz que espera la app ---------- */
  window.claude = Object.freeze({
    use: async name=>{
      await ready;
      if(name==='db') return DB;
      if(name==='assets') return ASSETS;
      if(name==='sample') return SAMPLE;
      return null;
    }
  });

  /* ---------- arranque ---------- */
  (async ()=>{
    if(!CFG.supabaseUrl || !CFG.supabaseAnonKey || !window.supabase){
      document.addEventListener('DOMContentLoaded', ()=>showLogin('Falta configurar Supabase (SUPABASE_URL y SUPABASE_ANON_KEY). Revisa la guía.'));
      return;
    }
    sb = window.supabase.createClient(CFG.supabaseUrl, CFG.supabaseAnonKey, {auth:{persistSession:true, autoRefreshToken:true, detectSessionInUrl:true}});
    let session = null;
    try{ const {data} = await sb.auth.getSession(); session = data && data.session; }catch(e){}
    if(session) start(session.user);
    else if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', ()=>showLogin());
    else showLogin();
  })();
})();
