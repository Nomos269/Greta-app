# GRETA · K9

App de entrenamiento personal de Greta: conducta, comandos, ruta, progreso y álbum de fotos y videos.

- **Samsung / Android:** app instalable (`Greta.apk`).
- **iPhone:** app web instalable desde Safari.
- **Actualizaciones automáticas:** la app abre siempre la versión publicada. Cada cambio que se sube a GitHub se publica solo en 1 o 2 minutos, y tus teléfonos lo reciben la próxima vez que abras la app. No hay que reinstalar nada.

## Qué incluye

- **Plan de 5 niveles:** Bases → Autocontrol → Calle tranquila → Confianza y mente → K9 · Buen Ciudadano. Cada nivel junta comandos, conducta, sonidos, socialización y una meta de la vida real, y termina con un **examen** que abre el siguiente.
- **Hoy:** tu ruta con el siguiente paso y un botón para empezarlo, acciones rápidas (paseo, clicker, sonidos, registrar), lo de hoy, pendientes y tu semana. Toca *Editar* para mostrar u ocultar más bloques.
- **Plan:** *Ruta*, un solo camino por nivel con cada paso en orden y el examen al final, y *Biblioteca*, con todos los ejercicios, programas, guías y herramientas.
- **Progreso:** resumen semanal y logros, reactividad y encuentros, álbum de fotos y videos con línea de tiempo, e historial.
- **Greta:** perfil, peso, salud, recordatorios y ajustes.

### Funciones del teléfono

| Función | Android (APK) | iPhone (Safari) |
|---|---|---|
| Recordatorios con notificación | Sí | Se muestran en “Pendientes” al abrir la app |
| Ruta GPS del paseo | Sí (pide permiso de ubicación) | Sí (pide permiso en Safari) |
| Pantalla encendida durante el paseo | Sí | Sí, en iOS 16.4 o más reciente |
| Funciona sin internet | Sí: los cambios se guardan y se sincronizan al volver la conexión | Sí, mismo comportamiento |
| Fotos y videos | Sí | Sí |

## Cómo está armada

| Pieza | Dónde vive | Para qué |
|---|---|---|
| Código | GitHub (este repositorio) | Guarda la app y publica cada cambio |
| App web | GitHub Pages | La dirección que abren Android y iPhone |
| Datos, fotos y videos | Supabase | Tu cuenta, privada y sincronizada |
| Entrenador con IA | Supabase Edge Function `coach` | Usa tu clave de Anthropic sin exponerla |
| APK de Android | GitHub Actions → Releases | Se compila en la nube, sin Android Studio |

---

## Instalación (una sola vez, unos 30 minutos)

### 1. GitHub

1. Crea una cuenta gratis en [github.com](https://github.com).
2. Crea un repositorio nuevo llamado **`greta`**, **público** (GitHub Pages es gratis solo en repositorios públicos). El código queda visible, pero los datos de Greta no: viven en tu Supabase, protegidos por tu cuenta.
3. Sube este proyecto. La forma más fácil:
   - En claude.ai conecta GitHub (**Configuración → Conectores → GitHub**) y dile a Claude tu usuario. Claude sube el código y, de ahí en adelante, cada actualización.
   - O súbelo a mano: en el repositorio, **Add file → Upload files** y arrastra todo el contenido de esta carpeta (incluida la carpeta oculta `.github`).

### 2. Supabase

1. Entra a [supabase.com](https://supabase.com) y crea un proyecto (por ejemplo `greta`). Guarda la contraseña de la base de datos.
2. **Base de datos:** menú **SQL Editor → New query**, pega todo el archivo `supabase/schema.sql` y presiona **Run**.
3. **Inicio de sesión:** menú **Authentication → Sign In / Providers → Email**. Déjalo activado. Si no quieres confirmar tu correo al crear la cuenta, desactiva **Confirm email**.
4. **Entrenador:**
   1. Saca tu clave en [console.anthropic.com](https://console.anthropic.com) → **API Keys** → **Create Key**.
   2. En Supabase: **Edge Functions → Secrets → Add new secret**: nombre `ANTHROPIC_API_KEY`, valor tu clave.
   3. **Edge Functions → Deploy a new function → Via Editor**, nombre **`coach`**, pega el archivo `supabase/functions/coach/index.ts` y presiona **Deploy**.
5. **Datos para conectar la app:** **Project Settings → API** (o **Data API**). Copia:
   - **Project URL** (algo como `https://xxxx.supabase.co`)
   - **anon public key**

### 3. Conectar GitHub con Supabase y publicar

1. En tu repositorio de GitHub: **Settings → Secrets and variables → Actions → pestaña Variables → New repository variable**. Crea dos:
   - `SUPABASE_URL` = tu Project URL
   - `SUPABASE_ANON_KEY` = tu anon public key
2. **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Pestaña **Actions**:
   - Abre **Publicar app web → Run workflow**. En 1 o 2 minutos tu app queda en `https://TU-USUARIO.github.io/greta/`.
   - Abre **Compilar APK de Android → Run workflow**. En unos 5 a 8 minutos aparece **Greta.apk** en la sección **Releases** del repositorio.

### 4. Instalar en tu Samsung

1. En el teléfono, abre `https://github.com/TU-USUARIO/greta/releases` y descarga **Greta.apk**.
2. Ábrelo. Si Android lo pide, permite **Instalar apps desconocidas** para el navegador o la app Mis archivos.
3. Si Google Play Protect muestra un aviso, elige **Instalar de todas formas** (la app no viene de la Play Store; es tuya).
4. Abre GRETA, toca **¿Primera vez? Crear cuenta** y entra.

### 5. Instalar en iPhone

1. Abre `https://TU-USUARIO.github.io/greta/` en **Safari**.
2. Toca **Compartir → Agregar a inicio**.
3. Entra con la misma cuenta: verás los mismos datos que en tu Samsung.

---

## Actualizaciones

- **Cambios de la app** (pantallas, ejercicios, diseño): se suben a GitHub, la app se vuelve a publicar sola y tus teléfonos la ven actualizada al abrirla.
- **El APK** solo se vuelve a descargar si cambia la parte nativa (ícono, nombre). Se firma siempre con la misma llave, así que se instala encima de la anterior sin borrar nada.

## Costos

- **GitHub:** gratis.
- **Supabase:** el plan gratis basta para empezar. Tiene un límite de espacio para archivos (fotos y videos); revisa su página de precios. Si lo llenas, puedes borrar videos viejos o subir de plan.
- **Anthropic:** pagas por uso del entrenador (centavos por pregunta). Puedes poner un límite de gasto en console.anthropic.com.

## Estructura del proyecto

```
src/app.html          La app (la misma que funciona dentro de Claude)
src/adapter.js        Conecta la app con Supabase (sesión, datos, fotos, entrenador)
src/shell.html        Página base: íconos, instalación, service worker
web/                  Manifest, íconos, service worker, página sin conexión
seed/estado.json      Datos iniciales de Greta (se cargan la primera vez)
supabase/             Esquema de la base de datos y función del entrenador
scripts/              Armado de la web y configuración de Android
assets/               Ícono y pantalla de inicio del APK
capacitor/            Llave de firma del APK (de depuración, no es secreta)
.github/workflows/    Publicación automática de la web y compilación del APK
```
