// Arma la app web en dist/ a partir de src/app.html (la misma app que corre en Claude)
// Uso: SUPABASE_URL=... SUPABASE_ANON_KEY=... SUPABASE_JS=ruta/supabase.js node scripts/build.mjs
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const r = p => path.join(root, p);
const dist = r('dist');
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(path.join(dist, 'vendor'), { recursive: true });

let app = fs.readFileSync(r('src/app.html'), 'utf8');
// Quitar el título y la meta propios del entorno de Claude (el shell ya los trae)
app = app.replace(/<title>[\s\S]*?<\/title>\s*/, '').replace(/<meta name="claude:viewport-fit-sides"[^>]*>\s*/, '');

// Ajustes para correr fuera de Claude
const swaps = [
  [`const blob = id=>'/_blob/'+id;`, `const blob = id=>window.gretaMediaUrl(id);`],
  [`const MAXV = 20*1024*1024;`, `const MAXV = 50*1024*1024;`],
  [`El archivo pesa más de 20 MB.`, `El archivo pesa más de 50 MB.`],
  [`Videos: MP4 o MOV de hasta 20 MB (unos 20 a 40 segundos).`, `Videos: MP4 o MOV de hasta 50 MB (alrededor de un minuto).`],
  [`El entrenador solo funciona abriendo la app desde Claude.`, `El entrenador no está disponible. Revisa tu conexión.`],
  [`Los datos y fotos se sincronizan entre tu teléfono y tu computadora.`, `Los datos y fotos se sincronizan entre tus dispositivos.<br><button class="txtbtn small" onclick="gretaLogout()">Cerrar sesión</button>`],
];
for (const [a, b] of swaps) {
  if (!app.includes(a)) { console.error('No se encontró el texto a reemplazar:', a); process.exit(1); }
  app = app.split(a).join(b);
}
app = app.split('desde la app en Claude').join('al iniciar sesión');

const shell = fs.readFileSync(r('src/shell.html'), 'utf8');
fs.writeFileSync(path.join(dist, 'index.html'), shell.replace('<!--APP-->', app));

// Configuración pública (la clave anon de Supabase es pública por diseño; la seguridad la dan las políticas RLS)
const cfg = { supabaseUrl: process.env.SUPABASE_URL || '', supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '' };
fs.writeFileSync(path.join(dist, 'config.js'), `window.GRETA_CONFIG = ${JSON.stringify(cfg)};\n`);

// Datos iniciales (se cargan solo la primera vez que entras y tu cuenta está vacía)
const seedPath = r('seed/estado.json');
const seed = fs.existsSync(seedPath) ? fs.readFileSync(seedPath, 'utf8') : 'null';
fs.writeFileSync(path.join(dist, 'seed.js'), `window.GRETA_SEED = ${seed.trim()};\n`);

fs.copyFileSync(r('src/adapter.js'), path.join(dist, 'adapter.js'));
for (const f of ['manifest.webmanifest', 'sw.js', 'offline.html', '.nojekyll']) {
  if (fs.existsSync(r('web/' + f))) fs.copyFileSync(r('web/' + f), path.join(dist, f));
}
fs.cpSync(r('web/icons'), path.join(dist, 'icons'), { recursive: true });

const sbjs = process.env.SUPABASE_JS;
if (sbjs && fs.existsSync(sbjs)) fs.copyFileSync(sbjs, path.join(dist, 'vendor/supabase.js'));
else console.warn('Aviso: no se encontró supabase.js (variable SUPABASE_JS). La app no podrá conectarse.');

// Versión para que el service worker detecte cambios
const version = new Date().toISOString();
const sw = path.join(dist, 'sw.js');
fs.writeFileSync(sw, fs.readFileSync(sw, 'utf8').replace('__VERSION__', version));
console.log('Listo: dist/ generado', version);
