from PIL import Image, ImageDraw, ImageFont
import os
F = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def grad(sz):
    im = Image.new('RGB',(sz,sz))
    d = ImageDraw.Draw(im)
    top=(13,110,226); bot=(8,58,140)
    for y in range(sz):
        t=y/(sz-1); d.line([(0,y),(sz,y)], fill=tuple(int(top[i]+(bot[i]-top[i])*t) for i in range(3)))
    return im
def mark(im, scale=1.0):
    sz = im.size[0]; d = ImageDraw.Draw(im)
    # silueta de orejas de pastor
    cx, cy = sz/2, sz*0.47; s = sz*0.30*scale
    d.polygon([(cx-s*0.95,cy-s*0.05),(cx-s*0.62,cy-s*1.15),(cx-s*0.22,cy-s*0.30)], fill=(255,255,255))
    d.polygon([(cx+s*0.95,cy-s*0.05),(cx+s*0.62,cy-s*1.15),(cx+s*0.22,cy-s*0.30)], fill=(255,255,255))
    d.ellipse([cx-s*0.92,cy-s*0.62,cx+s*0.92,cy+s*0.78], fill=(255,255,255))
    d.polygon([(cx-s*0.42,cy+s*0.45),(cx+s*0.42,cy+s*0.45),(cx,cy+s*1.15)], fill=(255,255,255))
    d.ellipse([cx-s*0.20,cy+s*0.78,cx+s*0.20,cy+s*1.08], fill=(28,28,30))
    d.ellipse([cx-s*0.45,cy-s*0.05,cx-s*0.25,cy+s*0.15], fill=(28,28,30))
    d.ellipse([cx+s*0.25,cy-s*0.05,cx+s*0.45,cy+s*0.15], fill=(28,28,30))
    f = ImageFont.truetype(F, int(sz*0.11*scale))
    t='GRETA'; w = d.textlength(t,font=f)
    d.text((cx-w/2, sz*0.80 - (1-scale)*sz*0.06), t, font=f, fill=(255,255,255))
def rounded(im, r):
    m = Image.new('L', im.size, 0); ImageDraw.Draw(m).rounded_rectangle([0,0,im.size[0]-1,im.size[1]-1], r, fill=255)
    out = Image.new('RGBA', im.size, (0,0,0,0)); out.paste(im, (0,0), m); return out
os.makedirs('web/icons', exist_ok=True)
for sz,name in [(512,'icon-512.png'),(192,'icon-192.png'),(180,'apple-touch-icon.png'),(32,'favicon-32.png')]:
    im = grad(sz); mark(im); im.save('web/icons/'+name)
im = grad(512); mark(im, 0.78); im.save('web/icons/icon-maskable-512.png')
# Capacitor assets
big = grad(1024); mark(big, 0.82); big.save('assets/icon-only.png')
bg = grad(1024); bg.save('assets/icon-background.png')
fg = Image.new('RGBA',(1024,1024),(0,0,0,0)); tmp = grad(1024); mark(tmp,0.62)
mask = Image.new('L',(1024,1024),0); md=ImageDraw.Draw(mask)
# foreground: solo la marca blanca
px = tmp.load(); fpx = fg.load()
for y in range(1024):
    for x in range(1024):
        r,g,b = px[x,y]
        if r>200 and g>200 and b>200: fpx[x,y]=(255,255,255,255)
        elif r<40 and g<40 and b<40: fpx[x,y]=(28,28,30,255)
fg.save('assets/icon-foreground.png')
sp = Image.new('RGB',(2732,2732),(242,242,247)); ic = rounded(grad(600),130); m2 = grad(600); mark(m2); sp.paste(rounded(m2,130),(1066,1066),rounded(m2,130)); sp.save('assets/splash.png')
spd = Image.new('RGB',(2732,2732),(0,0,0)); spd.paste(rounded(m2,130),(1066,1066),rounded(m2,130)); spd.save('assets/splash-dark.png')
print('icons ok')
