// Genera capacitor.config.json. La app Android abre la versión publicada en
// GitHub Pages, así que cada actualización de la web llega sola al teléfono.
import fs from 'node:fs';

const url = (process.env.APP_URL || '').toLowerCase();
if (!url.startsWith('https://')) {
  console.error('Falta APP_URL (por ejemplo https://usuario.github.io/greta/)');
  process.exit(1);
}
const config = {
  appId: 'com.lucasrod.greta',
  appName: 'GRETA',
  webDir: 'www',
  server: { url, cleartext: false, errorPath: 'index.html' },
  android: { allowMixedContent: false, backgroundColor: '#F2F2F7' }
};
fs.mkdirSync('www', { recursive: true });
fs.copyFileSync('web/offline.html', 'www/index.html');
fs.writeFileSync('capacitor.config.json', JSON.stringify(config, null, 2));
console.log('capacitor.config.json →', url);
