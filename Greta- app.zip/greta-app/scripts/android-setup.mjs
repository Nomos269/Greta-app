// Ajustes del proyecto Android después de `npx cap add android`:
// permisos de ubicación (modo paseo) y de notificaciones (recordatorios).
import fs from 'node:fs';

const file = 'android/app/src/main/AndroidManifest.xml';
let xml = fs.readFileSync(file, 'utf8');
const perms = [
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.VIBRATE',
  'android.permission.WAKE_LOCK'
];
const add = perms.filter(p => !xml.includes(p)).map(p => `    <uses-permission android:name="${p}" />`).join('\n');
if (add) xml = xml.replace(/<application/, `${add}\n\n    <application`);
fs.writeFileSync(file, xml);
console.log('Permisos agregados:', perms.length);
