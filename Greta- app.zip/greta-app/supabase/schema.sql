-- GRETA · esquema de Supabase
-- Pega todo este archivo en Supabase → SQL Editor → New query → Run.
-- Cada usuario solo puede ver y modificar sus propios datos (Row Level Security).

-- Estado general de Greta (niveles, programas, peso, hitos, diseño de Inicio...)
create table if not exists public.estado (
  user_id uuid primary key references auth.users(id) on delete cascade default auth.uid(),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- Sesiones de entrenamiento, registros de conducta y álbum
create table if not exists public.sesiones (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  id text not null,
  ts bigint not null,
  data jsonb not null,
  primary key (user_id, id)
);
create table if not exists public.registros (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  id text not null,
  ts bigint not null,
  data jsonb not null,
  primary key (user_id, id)
);
create table if not exists public.album (
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  id text not null,
  ts bigint not null,
  data jsonb not null,
  primary key (user_id, id)
);
create index if not exists sesiones_user_ts on public.sesiones (user_id, ts desc);
create index if not exists registros_user_ts on public.registros (user_id, ts desc);
create index if not exists album_user_ts on public.album (user_id, ts desc);

alter table public.estado enable row level security;
alter table public.sesiones enable row level security;
alter table public.registros enable row level security;
alter table public.album enable row level security;

drop policy if exists "estado propio" on public.estado;
create policy "estado propio" on public.estado for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "sesiones propias" on public.sesiones;
create policy "sesiones propias" on public.sesiones for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "registros propios" on public.registros;
create policy "registros propios" on public.registros for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "album propio" on public.album;
create policy "album propio" on public.album for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Almacenamiento privado de fotos y videos (máximo 50 MB por archivo)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', false, 52428800,
        array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'])
on conflict (id) do update set public = false, file_size_limit = 52428800,
  allowed_mime_types = excluded.allowed_mime_types;

-- Cada usuario solo accede a su carpeta: media/<su id>/...
drop policy if exists "media leer propia" on storage.objects;
create policy "media leer propia" on storage.objects for select to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "media subir propia" on storage.objects;
create policy "media subir propia" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "media borrar propia" on storage.objects;
create policy "media borrar propia" on storage.objects for delete to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
